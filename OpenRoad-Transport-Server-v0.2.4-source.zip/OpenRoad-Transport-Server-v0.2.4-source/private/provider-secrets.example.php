<?php
/** COPY to /home/bengoodm/openroad-private/provider-secrets.php (outside public_html).
 *  chmod 600 provider-secrets.php. Never commit or upload credentials to GitHub.
 *  More providers will be migrated incrementally; only Rail Data is active in v0.2.4.
 */
return [
    'raildata_consumer_key' => 'PASTE_YOUR_CONSUMER_KEY_HERE',
    // Future: bods_api_key, tfl_app_key, transportapi_app_id, transportapi_app_key
];
